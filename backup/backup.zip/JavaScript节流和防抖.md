http://www.css88.com/archives/6598

http://www.css88.com/archives/6589
```
/* 节流 函数
 * case 1
 * window.onscroll = throttle(testFn, 200);
 * // case 2
 * window.onscroll = throttle(testFn, 200, 500);
*/
function throttle(fn, delay, atleast) {
var timer = null;
 var previous = null;
 return function () {
  ow = +new Date();
  previous = now;
  ow - previous > atleast ) {
fn();
      ow;
        ction() {
    ();
      }
};
```